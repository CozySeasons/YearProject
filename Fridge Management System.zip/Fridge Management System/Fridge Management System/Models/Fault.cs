﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Fridge_Management_System.Models
{
    public class Fault
    {
        [Key]
        public int FaultID { get; set; }

        [Required(ErrorMessage = "Fault Description is required")]
        [StringLength(500, ErrorMessage = "Fault Description cannot exceed 500 characters")]
        public string? FaultDescription { get; set; }

        [StringLength(50, ErrorMessage = "Status cannot exceed 50 characters")]
        public string Status { get; set; } = "Pending"; // Default value

        [Required(ErrorMessage = "Fridge is required")]
        public int FridgeID { get; set; }

        [ForeignKey("FridgeID")]
        public virtual Fridge? Fridge { get; set; }
    }
}
