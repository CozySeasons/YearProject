﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace Fridge_Management_System.Models
{
    public class Employee
    {
        [Key, ForeignKey("User")]
        public string EmployeeId { get; set; }
        //public string Id { get; set; }
        [Required, StringLength(10)]
        public string Role { get; set; }
        public IdentityUser User { get; set; }

    }
}
