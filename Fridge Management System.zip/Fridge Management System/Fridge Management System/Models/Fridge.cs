﻿using System.ComponentModel.DataAnnotations;

namespace Fridge_Management_System.Models
{
    public class Fridge
    {
        [Key]
        public int FridgeID { get; set; }

        [Required(ErrorMessage = "Fridge Model is required")]
        public string? Model { get; set; }

        public string? SerialNumber { get; set; }

        public string? Status { get; set; }
    }
}
