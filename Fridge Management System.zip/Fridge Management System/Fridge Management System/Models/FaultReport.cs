﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Fridge_Management_System.Models
{
    public class FaultReport
    {
        [Key]
        public int ReportID { get; set; }

        [Required]
        public DateTime ReportDate { get; set; }

        public string? ReportDetails { get; set; }

        [Required]
        public int FaultID { get; set; }

        [ForeignKey("FaultID")]
        public Fault? Fault { get; set; }
    }
}
