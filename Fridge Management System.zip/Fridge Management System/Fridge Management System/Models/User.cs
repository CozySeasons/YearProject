﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace Fridge_Management_System.Models
{
    public class User: IdentityUser
    {
        [Required]
        [StringLength(50)]
        public string UserName { get; set; }
        [Required]
        [StringLength(50)]
        public string? Name { get; set; }
        [Required]
        [StringLength(50)]
        public string? Surname { get; set; }
        [Required]
        [StringLength(10)]
        public string? Gender { get; set; }
        [Required, DataType(DataType.Date)]
        public DateTime DOB { get; set; }
        [Required]
        [StringLength(100)]
        public string? Address { get; set; }
        [Required]
        [StringLength(50)]
        public string? City { get; set; }
        [Required]
        [StringLength(10)]
        public string? ZipCode { get; set; }
        [Required, StringLength(10)]
        public string? UserType { get; set; }
        [Required]
        public bool IsActive { get; set; }
        public ICollection<Employee>? Employees { get; set; }
        public ICollection<Customer>? Customers { get; set; }

    }
}
