﻿using System.ComponentModel.DataAnnotations;

namespace Fridge_Management_System.Models
{
    public class FaultTechnician
    {
        [Key]
        public int TechnicianID { get; set; }

        [Required(ErrorMessage = "Technician Name is required")]
        public string? FisrtName { get; set; }

        public string? LastName { get; set; }

        public string? Email { get; set; }
    }
}

