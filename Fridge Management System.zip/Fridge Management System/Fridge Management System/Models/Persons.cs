﻿using Microsoft.AspNetCore.Identity;

namespace Fridge_Management_System.Models
{
    public class Persons:IdentityRole
    {
        public const string Administrator = "Administrasator";
        public const string CustomerManager = "CustomerManager";
        public const string FaultTechnician = "FaultTechnician";
        public const string Maintenance = "Maintenance";
        public const string PurchasingManager = "PurchasingManager";
    }
}
