﻿using Fridge_Management_System.Models;
using Microsoft.EntityFrameworkCore;

namespace Fridge_Management_System.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }
        public DbSet<Fault> Faults { get; set; }
        public DbSet<Fridge> Fridges { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure relationships and constraints
            modelBuilder.Entity<Fault>()
                .HasOne(f => f.Fridge)
                .WithMany()
                .HasForeignKey(f => f.FridgeID)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }

}
